package test;


import bean.Password;
import bean.PwType;
import bean.Scheme;
import bean.User;
import util.Logger;
import util.PasswordConvertor;

import java.io.IOException;
import java.util.Random;

public class Test {
    public static void main(String[] args){
        Password password = new Password();
        password.setPassword(1234567);
        password = PasswordConvertor.convertPasswordTo(password,Scheme.IMAGE);
        System.out.println(password.getPassword_representative());
    }
}
