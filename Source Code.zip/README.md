# comp3008P2 

Available at http://largetimmo.me:8081
# Installation and Running Instructions:

1.Download tomcat(Version 8 or above)

2.Download idea Ultimate Version(You may skip this step, but you will tough time in the next few minutes. If you skip this step, go to step #4)

3. Using idea:

3.1 Import all of the code to idea.

3.2 Click Maven on the right nav bar then click +

3.3 Go to project root then select pom.xml

3.4 Click refresh button to let idea download all the libraries

3.5 Go to running configuration in idea, then click + button and select Tomcat-local

3.6 Add tomcat to application server

3.7 Save it and click run

4. Manually

4.1 check pom.xml, then download all the libs

4.2 compile all code

4.3 copy to the webapp folder

4.4 run tomcat



